#e2264562 Sahin Kasap
from finalq1 import *

final_q1("Dataset1","")