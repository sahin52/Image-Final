#e2264562 Sahin Kasap

from finalq2 import *

final_q2("Dataset2/1.jpg","2-1.jpg")
final_q2("Dataset2/2.jpg","2-2.jpg")
final_q2("Dataset2/3.jpg","2-3.jpg")
final_q2("Dataset2/4.jpg","2-4.jpg")
final_q2("Dataset2/5.jpg","2-5.jpg")
