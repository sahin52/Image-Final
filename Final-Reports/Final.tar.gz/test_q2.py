#e2264562 Sahin Kasap

from finalq2 import *

final_q2("Dataset2/3.jpg","2-1.jpg")
