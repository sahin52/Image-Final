#e2264562 Sahin Kasap
from finalq3 import *

final_q3("Dataset3/1.png","3-1.jpg")
#DONE