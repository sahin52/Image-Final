in q1, give input_file_path as only the name of the folder like:
Dataset1
and the output_folder is again the same:
Results1

in q2 and q3, give the specific names of the input and output files:
final_q2("Dataset2/input1.jpg","Result2-1.jpg")


The function are in final_qX.py files, and the tests are in test_qX.py files.
You can import the final_qX.py files into your working environment. OR you can test with the test_qX.py files.
I used python3